import sys
import os

# Our ISA Dictionary
opcodes = {
    "MVR": "0", "LDB": "1", "STB": "2", "RDS": "3",
    "NOT": "8", "AND": "9", "ORA": "A", "ADD": "B",
    "SUB": "C", "XOR": "D", "INC": "E"
}
try:
    with open("program.txt", "r") as f_in, open("machine_code.hex", "w") as f_out:
        for line_num, line in enumerate(f_in, 1):
            
            clean_line = line.split("//")[0].strip()
            if not clean_line: continue

            parts = clean_line.replace(",", "").split()
            command = parts[0].upper()

            if command not in opcodes:
                print(f"Error on line {line_num}: Unknown command '{command}'")
                continue

            if command == "LDB":
                r_dest = parts[1].replace("r", "")
                data = parts[2].replace("0x", "").zfill(2)
                f_out.write(f"{opcodes[command]}{r_dest}{data}\n")
            elif command in ["AND", "ORA", "ADD", "SUB", "XOR"]:
                r_dest = parts[1].replace("r", "")
                r_src1 = parts[2].replace("r", "")
                r_src2 = parts[3].replace("r", "")
                f_out.write(f"{opcodes[command]}{r_dest}{r_src1}{r_src2}\n")
            elif command in ["MVR", "NOT", "INC"]:
                r_dest = parts[1].replace("r", "")
                r_src1 = parts[2].replace("r", "")
                f_out.write(f"{opcodes[command]}{r_dest}{r_src1}0\n")
            elif command == "STB":
                r_src = parts[1].replace("r", "")
                f_out.write(f"{opcodes[command]}{r_src}00\n")
            elif command == "RDS":
                f_out.write(f"{opcodes[command]}000\n")
                print("Assembly complete! 'machine_code.hex' has been updated.")

except FileNotFoundError:
    print("Error: Could not find 'program.txt'.")

except IndexError:
    print("Error: Missing register or number on one of your lines.")
