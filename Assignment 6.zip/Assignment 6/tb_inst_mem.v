
module tb_inst_mem();

    reg [7:0] addr;

    wire [15:0] inst_out;

ins_mem uut (
    .addr(addr),
    .inst_out(inst_out)
);

    initial begin
        $dumpfile("waves.vcd");
        $dumpvars(0,tb_inst_mem);
        addr = 8'd0; #10;
        addr = 8'd1; #10;
        addr = 8'd2; #10;
        addr = 8'd3; #10;
        addr = 8'd4; #10;
        addr = 8'd5; #10;
        addr = 8'd6; #10;


        // Check an empty slot just to see what happens (should be xxxx or 0000)
        addr = 8'd10; #10;

        $finish;
    end
endmodule