module ins_mem(
    input [7:0] addr,
    output reg [15:0] inst_out
);

reg [15:0] mem [0:255];

initial begin
   
mem[0] = 16'b0000011000100100; // NOT R3,R1
mem[1] = 16'b0010011000100100; // AND R3,R1,R2
mem[2] = 16'b0100011000100100; // OR  R3,R1,R2
mem[3] = 16'b0110011000100100; // ADD R3,R1,R2
mem[4] = 16'b1000011000100100; // SUB R3,R1,R2
mem[5] = 16'b1010011000100100; // XOR R3,R1,R2
mem[6] = 16'b1100011000100100; // INC R3,R1

end

always @(*) begin
    inst_out = mem[addr];
end

endmodule