module tb_ripple;

reg [3:0]a;
reg [3:0]b;
wire greater, lesser, equal;

ripple uut(
    .a(a),.b(b),.greater(greater),.lesser(lesser), .equal(equal)
);

initial begin 
$dumpfile("waves.vcd");
$dumpvars(0,tb_ripple);

// this id for greater case
a=4'b1111; b=4'b1011;
#10;


// this is for lower case
a=4'b1001; b=4'b1011;
#10;

// this is for equal case
a=4'b1011; b=4'b1011;
#10;

$finish;
end 
endmodule