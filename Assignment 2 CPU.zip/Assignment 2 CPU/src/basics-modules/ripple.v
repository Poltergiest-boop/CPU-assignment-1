module ripple(input [3:0]a , input [3:0]b, output greater , output lesser, output equal );
    wire[3:0] g,l,e;

    comparator third(.A(a[3]), .B(b[3]), .G(g[3]), .L(l[3]), .E(e[3]));
    comparator second(.A(a[2]), .B(b[2]), .G(g[2]), .L(l[2]), .E(e[2]));
    comparator first(.A(a[1]), .B(b[1]), .G(g[1]), .L(l[1]), .E(e[1]));
    comparator zeroth(.A(a[0]), .B(b[0]), .G(g[0]), .L(l[0]), .E(e[0]));

    assign equal=(e[3]&e[2]&e[1]&e[0])?1:0;
    assign greater=((g[3])|(e[3]&g[2])|(e[3]&e[2]&g[1])|(e[3]&e[2]&e[1]&g[0]));
    assign lesser= ((l[3])|(e[3]&l[2])|(e[3]&e[2]&l[1])|(e[3]&e[2]&e[1]&l[0]));

endmodule

module comparator(input A , input B, output G, output L, output E);
    assign L= (~A)&B;
    assign G= A&(~B);
    assign E= ~(A^B);
endmodule    