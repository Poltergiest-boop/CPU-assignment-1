#!/bin/bash
echo "Compiling and running standalone module simulation..."
# iverilog -g2012 -I src -o test/sim.vvp src/project.v test/tb.v   # PATH CHANGES HERE

# make sure to be in the root directory of the project. Else paths will be different.
iverilog -g2012 -I src -o src/basic-test/sim.vvp src/basics-modules/basic-module1.v src/basics-testbenches/basic-testbench1.v

# note that for different files, the test bench and module arguments will change.

vvp src/basic-test/sim.vvp
echo "Done! Click on the .vcd file to view waveforms."


# USE THE ABOVE COMMANDS TO compile and run the simulation


# COMMANDS TO PUSH INTO THE GITHUB REPO ON THIS BRANCH IF USING CODESPACE

# 1. Double check that your prompt says (basics) and not a random number
git checkout basics
git add .
git commit -m "Added 3 new practice files to basics track"
git pull --rebase origin basics
git push origin basics


# note, for these changes to reflect on the local machine. (in case you're also keeping the files local)
git checkout basics # basics should be replaced by whatever branch you're using, I recommend not using any branches make all changes to your main branch itself
git pull origin basics