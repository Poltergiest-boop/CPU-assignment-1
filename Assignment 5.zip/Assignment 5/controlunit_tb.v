module controlunit_tb;
    reg [15:0] instruction;
    wire write_enable;
    wire [2:0] alu_op;
    wire [3:0] read_address1,read_address2,write_address;

controlunit uut(
    .instruction(instruction),
    .write_enable(write_enable),
    .alu_op(alu_op),
    .read_address1(read_address1),
    .read_address2(read_address2),
    .write_address(write_address)
);

initial begin 
$dumpfile("waves.vcd");
$dumpvars(0,controlunit_tb);


//case 1 NOT
instruction=16'b0000001100010010;
#10;

//case 2 AND
instruction=16'b0001001100010010;
#10;

//case 3 OR
instruction=16'b0010001100010010;
#10;

//case 4 ADD
instruction=16'b0011001100010010;
#10;

//case 5 SUB
instruction=16'b0100001100010010;
#10;

//case 6 XOR
instruction=16'b0101001100010010;
#10;

//case 7 INC
instruction=16'b0110001100010010;
#10;

//case 8 invalid opcode 
instruction=16'b1111001100010010;
#10;

$finish;
end
endmodule