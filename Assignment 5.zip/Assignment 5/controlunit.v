module controlunit(
    input [15:0] instruction,
    output reg write_enable,
    output reg [2:0] alu_op,
    output reg [3:0] read_address1,
    output reg [3:0] read_address2,
    output reg [3:0] write_address
);

always@(*)
begin
case(instruction[15:12])
    4'b0000:begin
            alu_op=3'b000;
            write_enable=1'b1;
            end
    4'b0001:begin
            alu_op=3'b001;
            write_enable=1'b1;
            end
    4'b0010:begin
            alu_op=3'b010;
            write_enable=1'b1;
            end
    4'b0011:begin
            alu_op=3'b011;
            write_enable=1'b1;
            end 
    4'b0100:begin
            alu_op=3'b100;
            write_enable=1'b1;
            end 
    4'b0101:begin
            alu_op=3'b101;
            write_enable=1'b1;
            end
    4'b0110:begin
            alu_op=3'b110;
            write_enable=1'b1;
            end
    default:begin
            write_enable=1'b0;
            alu_op=3'b000;
            end
endcase 

write_address=instruction[11:8];
read_address1=instruction[7:4];
read_address2=instruction[3:0];

end 
endmodule

    