module final_tb;
reg clk, rst,write_enable;
    reg [3:0] write_address ,read_address1,read_address2;
    reg  [7:0] write_data ;
    wire [7:0] read_data1 , read_data2;

register_file RF(
    .clk(clk), .rst(rst), .write_enable(write_enable), .write_address(write_address), .read_address1(read_address1),
    .read_address2(read_address2), .write_data(write_data), .read_data1(read_data1), .read_data2(read_data2)
);

 
reg [7:0] in1,in2;
    reg [2:0] alu_op;
    wire carry_flag;
    wire [7:0] result;

alu ALU(
    .in1(read_data1),
    .in2(read_data2),
    .alu_op(alu_op),
    .carry_flag(carry_flag),
    .result(result)
);

initial begin 
clk=0;
rst=0;
write_enable=0;
write_address=0;
write_data=0;
read_address1=0;
read_address2=0;
end 
always #5 clk= ~clk;

initial begin 
$dumpfile("waves.vcd");
$dumpvars(0,final_tb);

// case asked to test 
write_enable=1'b1;          // 5 in R1
write_address=4'b0001;
write_data=8'd5;
read_address1=4'b0001;
#10;
write_enable=1'b1;          // 3 in R2
write_address=4'b0010;
write_data=8'd3;
read_address2=4'b0010;
#10;
alu_op=3'b011;
#10;
write_enable=1'b1;
write_address=4'b0011;
write_data=result;
read_address1=4'b0011;
#10;

$finish;
end 
endmodule


