module alu_tb;
    reg [7:0] in1,in2;
    reg [2:0] alu_op;
    wire carry_flag;
    wire [7:0] result;

alu uut(
    .in1(in1),
    .in2(in2),
    .alu_op(alu_op),
    .carry_flag(carry_flag),
    .result(result)
);

initial begin 
$dumpfile("waves.vcd");
$dumpvars(0,alu_tb);


//case 1 NOT
in1=8'd13;
in2=8'd11;
alu_op=3'b000;
#10;
$display("NOT result=%d carry=%b", result, carry_flag);

//case 2 AND
in1=8'd10;
in2=8'd11;
alu_op=3'b001;
#10;
$display("AND result=%d carry=%b", result, carry_flag);

//case 3 OR
in1=8'd10;
in2=8'd11;
alu_op=3'b010;
#10;
$display("OR result=%d carry=%b", result, carry_flag);

//case 4 ADD
in1=8'd10;
in2=8'd11;
alu_op=3'b011;
#10;
$display("ADD result=%d carry=%b", result, carry_flag);

//case 5 SUB
in1=8'd10;
in2=8'd11;
alu_op=3'b100;
#10;
$display("SUB result=%d carry=%b", result, carry_flag);

//case 6 XOR
in1=8'd10;
in2=8'd11;
alu_op=3'b101;
#10;
$display("XOR result=%d carry=%b", result, carry_flag);

//case 7 INC
in1=8'd255;
in2=8'd11;
alu_op=3'b110;
#10;
$display("INC result=%d carry=%b", result, carry_flag);

$finish;
end
endmodule