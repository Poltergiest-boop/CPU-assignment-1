module register_file_tb;

    reg clk, rst,write_enable;
    reg [3:0] write_address ,read_address1,read_address2;
    reg  [7:0] write_data ;
    wire [7:0] read_data1 , read_data2;

register_file uut(
    .clk(clk), .rst(rst), .write_enable(write_enable), .write_address(write_address), .read_address1(read_address1),
    .read_address2(read_address2), .write_data(write_data), .read_data1(read_data1), .read_data2(read_data2)
);

initial begin 
clk=0;
rst=0;
write_enable=0;
write_address=0;
write_data=0;
read_address1=0;
read_address2=0;
end 

always #5 clk=~clk;
initial begin
$dumpfile("waves.vcd");
$dumpvars(0,register_file_tb);

// case 1 for writing a value of 5 in register 3     0ns to 10ns
write_enable=1'b1;
write_address=4'b0011;
write_data=8'd5;
read_address1=4'b0011;
#10;

// case 2 reset after writing     10ns to 20ns 
write_enable=1'b0;
rst=1'b1;
#10;

// case 3 :reading two values together 
// for that first storing two values during 20ns to 40ns 

rst=1'b0;
read_address1=4'b0011;
read_address2=4'b0100;
write_enable=1'b1;
write_address=4'b0011; // storing 5 in 3
write_data=8'd5;
#10;
write_enable=1'b1;
write_address=4'b0100; // storing 8 in 4
write_data=8'd8;
#10;

// case 4 overwriting 6 in register 3     40ns to 50ns
write_enable=1'b1;
write_address=4'b0011; // storing 6 in 3
write_data=8'd6;
#10;

// case 5 attempting to write 7 in 5 when enable is 0   50ns to 60ns
read_address1=4'b0101;
write_enable=1'b0;
write_address=4'b0101; // storing 7 in 5
write_data=8'd7;
#10;    // it failed because enable is 0

// case 6 read data before and after clock edge     60ns to 70ns
write_enable=1'b1;
write_address=4'b0101; // storing 7 in 5
write_data=8'd7;                                // initially at 60ns it was 00
#10;                                            // then at 70ns it is 7

//case 7 writing after reset            70ns to 90ns
rst=1'b1;
#10;
rst=1'b0;
write_enable=1'b1
write_address=4'b0101; // storing 9 in 5
write_data=8'd9;  
#10;

$finish;

end 
endmodule

