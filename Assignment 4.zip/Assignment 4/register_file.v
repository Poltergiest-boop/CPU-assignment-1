module register_file(
     input clk,
    input  rst,
     input write_enable,
    input  [3:0] write_address ,
    input  [7:0] write_data ,
     input [3:0] read_address1 ,
     input [3:0] read_address2 ,
    output [7:0] read_data1 ,
    output [7:0] read_data2 
);
reg [7:0] Reg_file [15:0];

assign read_data1 = Reg_file[read_address1];
assign read_data2 = Reg_file[read_address2];

integer i;
always @(posedge clk )
begin 

if(rst)
begin
    for(i=0;i<=15;i=i+1)
    begin
        Reg_file[i]<=8'b00000000;

    end 
end 


else if(write_enable& (~rst))
begin 
    Reg_file[write_address]<=write_data;
end
end 
endmodule







