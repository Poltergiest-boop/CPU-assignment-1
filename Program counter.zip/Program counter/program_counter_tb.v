module program_counter_tb;
    reg clk;
    reg rst;
    wire [7:0]pc;

program_counter uut(
    .clk(clk),
    .rst(rst),
    .pc(pc)
);

initial begin 
clk=0;
rst=1;
end

always #5 clk=~clk;
initial begin 

$dumpfile("waves.vcd");
$dumpvars(0,program_counter_tb);

//case 1 
#10;

//case 2 
rst=0;
#10;

//case 3 
#10;

//case 4 
#10;
#300;

$monitor("Time=%0t clk=%b rst=%b pc=%d",
             $time, clk, rst, pc);

$finish;

end 
endmodule