module program_counter(
    input clk,
    input rst,
    output reg [7:0]pc
);

always @(posedge clk)

if(rst)
begin 
   pc<=8'd0;
end
else
begin 
    pc<=pc+1;
end

endmodule
