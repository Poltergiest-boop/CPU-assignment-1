module Gray_to_sevensegment_tb;


reg [2:0]G;
wire a,b,c,d,e,f,g;

Gray_to_sevensegment uut(
    .G(G), .a(a), .b(b), .c(c), .d(d), .e(e), .f(f), .g(g)
);


initial begin
$dumpfile("waves.vcd");
$dumpvars(0,Gray_to_sevensegment_tb);

//for 0

G=3'b000;
#10;

//for 1

G=3'b001;
#10;

//for 2

G=3'b011;
#10;

//for 3

G=3'b010;
#10;

//for 4

G=3'b110;
#10;

//for 5

G=3'b111;
#10;

//for 6

G=3'b101;
#10;

//for 7

G=3'b100;
#10;

$finish;

end 
endmodule
