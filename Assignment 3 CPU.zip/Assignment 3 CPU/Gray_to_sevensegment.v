module Gray_to_sevensegment(
    input [2:0]G,
    output a,
    output b,
    output c,
    output d,
    output e,
    output f,
    output g
);

wire A,B,C;
assign A=G[2];
assign B=G[1];
assign C=G[0];

assign a = (B & C) | (A & ~B) | (~A & ~C);

assign b = (~A) | (A & ~C);

assign c = A | (~B) | (~C);

assign d = (A & C) | (~A & B) | (~A & ~C);

assign e = (~A & ~B & ~C) | (A & ~B & C) | (~A & B & C);

assign f = (A & B) | (A & C) | (~A & ~B & ~C);

assign g = B | (A & C);

endmodule